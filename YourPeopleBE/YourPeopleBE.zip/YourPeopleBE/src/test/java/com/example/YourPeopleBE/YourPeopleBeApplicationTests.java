package com.example.YourPeopleBE;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class YourPeopleBeApplicationTests {

	@Test
	void contextLoads() {
	}

}
